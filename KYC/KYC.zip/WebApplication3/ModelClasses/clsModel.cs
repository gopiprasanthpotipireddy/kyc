﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KYC
{
    public class clsModel
    {
        public string ClientName { get; set; }
        public int ClientID { get; set; }
        public string Procedure { get; set; }
        public string Risk { get; set; }
        public string Designation { get; set; }
        public string testing { get; set; }
        //public List<clsModel> p = new List<clsModel>();
        //public List<clsModel> p1 {
        //    get;
        //    set;
        //    }

        
    }
   
}