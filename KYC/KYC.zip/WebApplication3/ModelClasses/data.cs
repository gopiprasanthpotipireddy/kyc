﻿namespace KYC
{
    internal class data : clsModel
    {
        public int Id { get; set; }
        public string Message { get; set; }
        public int SSN { get; set; }
    }
}