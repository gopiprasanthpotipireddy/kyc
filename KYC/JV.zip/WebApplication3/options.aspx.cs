﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using Newtonsoft.Json;


namespace WebApplication3
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           

        }

        protected void submit_OnClick(object sender, EventArgs e)
        {
            //testc.clientname = textbox1.Value;
            //string test = new HtmlDocument(Microsoft.VisualStudio.TestTools.UITesting.UITestControl).GetElementById("txtbox1");
            //var test2=new HtmlDocument.GetElementById("txtbox2");

            clsModel obj = new clsModel();
            obj.ClientName = txtbox1.Value;
            obj.ClientID = int.Parse(Text2.Value);
            obj.Procedure = rd1.Value;
            obj.Risk = rd3.Value;
            obj.Designation = rd5.Value;
            obj.testing = rd7.Value;

            clsJSONTest obj1 = new clsJSONTest();
            obj1.fun(obj);

            //AddintoJSON(test);
        }
        //protected void sub1_click(object sender, EventArgs e) {

        //    //testc.clientname = textbox1.Value;

        //    clsModel obj = new clsModel();
        //    obj.ClientName = textbox1.Value;
        //    obj.ClientID = int.Parse(textbox2.Value);
        //    obj.Procedure = rd1.Value;


        //    clsJSONTest obj1 = new clsJSONTest();
        //    obj1.fun(obj);

        //    //AddintoJSON(test);
        //}

    }
}
