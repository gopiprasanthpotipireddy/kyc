﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace WebApplication3
{
    public class clsJSONTest
    {
        public void fun(clsModel obj) {

        //    clsModel obj2 = new clsModel();
        //    List<clsModel> _data = new List<clsModel>();
        //    _data.Add(new clsModel()
        //    {
        //    //   obj2.ClientName = obj.ClientName;
        //    //obj2.ClientID;
        //    //obj2.Procedure;

        //});


            string json = JsonConvert.SerializeObject(obj, Formatting.Indented);
            System.IO.File.AppendAllText(@"C:\Users\keerthik\Documents\non-linear-office-a\KYC\WebApplication3\json.json", JsonConvert.SerializeObject(obj, Formatting.Indented));
        }
        // serialize JSON to a string and then write string to a file
        //File.WriteAllText(@"c:\movie.json", JsonConvert.SerializeObject(obj));

        

        //// serialize JSON directly to a file
        //using (StreamWriter file = File.CreateText(@"c:\movie.json"))
        //{
        //    JsonSerializer serializer = new JsonSerializer();

        //        JsonSerializer.Serialize(file, movie);
        //}
    }
   
}
